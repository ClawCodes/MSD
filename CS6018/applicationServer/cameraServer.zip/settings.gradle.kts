rootProject.name = "cameraServer"

dependencyResolutionManagement {
    repositories {
        mavenCentral()
    }
}
