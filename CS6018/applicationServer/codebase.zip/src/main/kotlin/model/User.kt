package com.example.model

data class User(
  //val id: UUID,
  val username: String,
  //val hashedPassword: String //bcrypt so it includes salt, etc
)