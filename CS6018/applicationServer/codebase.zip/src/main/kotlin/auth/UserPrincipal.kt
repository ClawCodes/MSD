package com.example.auth

data class UserPrincipal(val id: String)