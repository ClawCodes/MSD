//
// Created by Christopher Lawton on 3/4/25.
//

#ifndef HELPER_H
#define HELPER_H

void *allocatePage(long numBytes);

#endif  // HELPER_H
