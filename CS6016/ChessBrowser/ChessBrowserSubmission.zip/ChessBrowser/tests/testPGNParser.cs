using System.Diagnostics;
using ChessBrowser;

public class TestParser {
    public static void testParseHeader(){
        // Arrange
        // PGNParser parser = new PGNParser();
        
        // Act
        // parser.parse("tests/data/singleGame.pgn");

        // Assert
        Debug.WriteLine("TEST");
    }

    public static void run(){
        testParseHeader();
    }
}