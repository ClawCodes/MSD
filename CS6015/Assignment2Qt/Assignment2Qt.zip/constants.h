#ifndef CONSTANTS_H
#define CONSTANTS_H

struct Dimension {
  int Width;
  int Height;
};

constexpr Dimension BG = {1118, 720};

#endif  // CONSTANTS_H
